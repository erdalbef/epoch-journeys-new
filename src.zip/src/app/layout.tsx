import type { Metadata } from "next";
import "./globals.css";
import { Geist } from "next/font/google";
import { cn } from "@/lib/utils";
import { Toaster } from "sonner";
import Analytics from "@/components/Analytics";

const geist = Geist({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: "Epoch Journeys",
  description: "B2B tour operator platform",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={cn("font-sans", geist.variable)}>
      <body>
        {children}

        {/* TOAST SYSTEM */}
        <Toaster richColors position="top-right" />

        <Analytics />
      </body>
    </html>
  );
}