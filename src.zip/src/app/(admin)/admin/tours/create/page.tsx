import { redirect } from "next/navigation";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

import { db } from "@/lib/db";
import TourForm from "@/components/admin/TourForm";
import { generateTourCode } from "@/lib/codes/generateTourCode";

// ============================================================
// PARSING HELPERS
// ============================================================

function parseCommaSeparated(
  value: FormDataEntryValue | null,
): string[] {
  if (!value || typeof value !== "string") {
    return [];
  }

  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function parseOptionalString(
  value: FormDataEntryValue | null,
): string | null {
  if (!value || typeof value !== "string") {
    return null;
  }

  const trimmed = value.trim();

  return trimmed || null;
}

function parseOptionalPositiveNumber(
  value: FormDataEntryValue | null,
): number | null {
  if (
    value === null ||
    typeof value !== "string" ||
    value.trim() === ""
  ) {
    return null;
  }

  const parsed = Number(value);

  if (
    !Number.isFinite(parsed) ||
    parsed < 0
  ) {
    return null;
  }

  return parsed;
}

function parseOptionalPositiveInteger(
  value: FormDataEntryValue | null,
): number | null {
  if (
    value === null ||
    typeof value !== "string" ||
    value.trim() === ""
  ) {
    return null;
  }

  const parsed = Number(value);

  if (
    !Number.isInteger(parsed) ||
    parsed <= 0
  ) {
    return null;
  }

  return parsed;
}

function parseCurrency(
  value: FormDataEntryValue | null,
): string {
  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    return "EUR";
  }

  return value
    .trim()
    .toUpperCase();
}

function parseCheckbox(
  formData: FormData,
  name: string,
): boolean {
  return formData.get(name) === "on";
}

// ============================================================
// FILE HELPERS
// ============================================================

function sanitizeFileName(
  fileName: string,
): string {
  return fileName
    .replace(/\s+/g, "-")
    .replace(
      /[^a-zA-Z0-9._-]/g,
      "",
    );
}

async function saveFile(
  file: File | null,
  folder: string,
): Promise<string | null> {
  if (!file || file.size === 0) {
    return null;
  }

  const bytes =
    await file.arrayBuffer();

  const buffer =
    Buffer.from(bytes);

  const safeName =
    sanitizeFileName(file.name);

  const fileName =
    `${Date.now()}-${safeName}`;

  const directoryPath =
    path.join(
      process.cwd(),
      "public",
      folder,
    );

  await mkdir(
    directoryPath,
    {
      recursive: true,
    },
  );

  const filePath =
    path.join(
      directoryPath,
      fileName,
    );

  await writeFile(
    filePath,
    buffer,
  );

  return `/${folder}/${fileName}`;
}

// ============================================================
// CREATE JOURNEY
// ============================================================

async function createTour(
  formData: FormData,
) {
  "use server";

  // ==========================================================
  // REQUIRED CORE FIELDS
  // ==========================================================

  const title =
    formData
      .get("title")
      ?.toString()
      .trim();

  const category =
    formData
      .get("category")
      ?.toString()
      .trim() ||
    "Pilgrimage";

  const duration =
    Number(
      formData.get("duration"),
    );

  if (
    !title ||
    !Number.isFinite(duration) ||
    duration < 1
  ) {
    return;
  }

  // ==========================================================
  // JOURNEY IDENTITY
  // ==========================================================

  const subtitle =
    parseOptionalString(
      formData.get("subtitle"),
    );

  const arrivalCity =
    parseOptionalString(
      formData.get(
        "arrivalCity",
      ),
    );

  const departureCity =
    parseOptionalString(
      formData.get(
        "departureCity",
      ),
    );

  const destinations =
    parseCommaSeparated(
      formData.get(
        "destinations",
      ),
    );

  const subcategories =
    parseCommaSeparated(
      formData.get(
        "subcategories",
      ),
    );

  const tags =
    parseCommaSeparated(
      formData.get("tags"),
    );

  // ==========================================================
  // STORYTELLING
  // ==========================================================

  const shortDescription =
    parseOptionalString(
      formData.get(
        "shortDescription",
      ),
    );

  const overview =
    parseOptionalString(
      formData.get("overview"),
    );

  const tourIntroduction =
    parseOptionalString(
      formData.get(
        "tourIntroduction",
      ),
    );

  const tourSignificance =
    parseOptionalString(
      formData.get(
        "tourSignificance",
      ),
    );

  const whyWeOfferThisTour =
    parseOptionalString(
      formData.get(
        "whyWeOfferThisTour",
      ),
    );

  const destinationBriefs =
    parseOptionalString(
      formData.get(
        "destinationBriefs",
      ),
    );

  // ==========================================================
  // AGENT / SALES CONTENT
  // ==========================================================

  const highlights =
    parseCommaSeparated(
      formData.get(
        "highlights",
      ),
    );

  const idealFor =
    parseCommaSeparated(
      formData.get(
        "idealFor",
      ),
    );

  const agentSellingPoints =
    parseCommaSeparated(
      formData.get(
        "agentSellingPoints",
      ),
    );

  // ==========================================================
  // SPIRITUAL / JOURNEY CHARACTER
  // ==========================================================

  const walkingLevel =
    parseOptionalString(
      formData.get(
        "walkingLevel",
      ),
    );

  const pace =
    parseOptionalString(
      formData.get("pace"),
    );

  const massIncluded =
    parseCheckbox(
      formData,
      "massIncluded",
    );

  // ==========================================================
  // JOURNEY CONTENT
  // ==========================================================

  const inclusions =
    parseCommaSeparated(
      formData.get(
        "inclusions",
      ),
    );

  const exclusions =
    parseCommaSeparated(
      formData.get(
        "exclusions",
      ),
    );

  const accommodations =
    parseCommaSeparated(
      formData.get(
        "accommodations",
      ),
    );

  const hotelStandard =
    parseOptionalString(
      formData.get(
        "hotelStandard",
      ),
    );

  const mealPlan =
    parseOptionalString(
      formData.get(
        "mealPlan",
      ),
    );

  const transportationSummary =
    parseOptionalString(
      formData.get(
        "transportationSummary",
      ),
    );

  const overviewItinerary =
    parseOptionalString(
      formData.get(
        "overviewItinerary",
      ),
    );

  const itinerary =
    parseOptionalString(
      formData.get(
        "itinerary",
      ),
    );

  // ==========================================================
  // COMMERCIAL REFERENCE
  // ==========================================================

  const startingPrice =
    parseOptionalPositiveNumber(
      formData.get(
        "startingPrice",
      ),
    );

  const currency =
    parseCurrency(
      formData.get(
        "currency",
      ),
    );

  const startingPriceBasis =
    parseOptionalString(
      formData.get(
        "startingPriceBasis",
      ),
    ) ||
    "DOUBLE_TWIN";

  const referenceGroupSize =
    parseOptionalPositiveInteger(
      formData.get(
        "referenceGroupSize",
      ),
    );

  const singleSupplementFrom =
    parseOptionalPositiveNumber(
      formData.get(
        "singleSupplementFrom",
      ),
    );

  // ==========================================================
  // FILES
  // ==========================================================

  const mainImage =
    formData.get(
      "mainImage",
    ) as File | null;

  const image2 =
    formData.get(
      "image2",
    ) as File | null;

  const image3 =
    formData.get(
      "image3",
    ) as File | null;

  const image4 =
    formData.get(
      "image4",
    ) as File | null;

  const mapImage =
    formData.get(
      "mapImage",
    ) as File | null;

  const brochure =
    formData.get(
      "brochure",
    ) as File | null;

  const [
    mainImageUrl,
    imageUrl2,
    imageUrl3,
    imageUrl4,
    mapImageUrl,
    brochureUrl,
  ] = await Promise.all([
    saveFile(
      mainImage,
      "uploads/tours",
    ),

    saveFile(
      image2,
      "uploads/tours",
    ),

    saveFile(
      image3,
      "uploads/tours",
    ),

    saveFile(
      image4,
      "uploads/tours",
    ),

    saveFile(
      mapImage,
      "uploads/maps",
    ),

    saveFile(
      brochure,
      "uploads/brochures",
    ),
  ]);

  // ==========================================================
  // TOUR CODE
  // ==========================================================

  const tourCode =
    await generateTourCode(
      title,
    );

  // ==========================================================
  // CREATE JOURNEY
  // ==========================================================

  const tour =
    await db.tour.create({
      data: {
        // --------------------------------------
        // JOURNEY IDENTITY
        // --------------------------------------

        title,
        subtitle,

        tourCode,

        category,
        subcategories,
        tags,
        destinations,

        duration,

        arrivalCity,
        departureCity,

        // --------------------------------------
        // STORYTELLING
        // --------------------------------------

        shortDescription,
        overview,
        tourIntroduction,
        tourSignificance,
        whyWeOfferThisTour,
        destinationBriefs,

        // --------------------------------------
        // AGENT / SALES CONTENT
        // --------------------------------------

        highlights,
        idealFor,
        agentSellingPoints,

        walkingLevel,
        pace,
        massIncluded,

        // --------------------------------------
        // JOURNEY CONTENT
        // --------------------------------------

        inclusions,
        exclusions,
        accommodations,

        hotelStandard,
        mealPlan,
        transportationSummary,

        overviewItinerary,
        itinerary,

        // --------------------------------------
        // COMMERCIAL REFERENCE
        // --------------------------------------

        startingPrice,
        currency,

        startingPriceBasis,

        referenceGroupSize,
        singleSupplementFrom,

        /*
         * Epoch Journeys' current pilgrimage
         * model:
         *
         * Private groups
         * + requested dates
         * + official NET quote.
         */
        pricingType:
          "GROUP_BASED",

        requiresQuote:
          true,

        /*
         * Legacy FIT/privatePricing data is
         * intentionally not populated for
         * new pilgrimage journeys.
         */
        privatePricing:
          undefined,

        // --------------------------------------
        // MEDIA
        // --------------------------------------

        mainImageUrl,
        imageUrl2,
        imageUrl3,
        imageUrl4,

        mapImageUrl,
        brochureUrl,

        // --------------------------------------
        // PUBLISHING
        // --------------------------------------

        featured:
          parseCheckbox(
            formData,
            "featured",
          ),

        isPublished:
          parseCheckbox(
            formData,
            "isPublished",
          ),
      },
    });

  // ==========================================================
  // NEXT STEP
  // ==========================================================

  /*
   * Correct workflow:
   *
   * Create Journey
   * → Seasonal Rate Guidance
   * → Official Quote
   * → Accepted Quote
   * → Booking
   */

  redirect(
    `/admin/tours/${tour.id}/seasonal-prices`,
  );
}

// ============================================================
// PAGE
// ============================================================

export default function CreateTourPage() {
  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#8B0000]">
          Journey Development
        </p>

        <h1 className="mt-2 text-3xl font-bold tracking-tight text-[#001F3F]">
          Create a Journey
        </h1>

        <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
          Build the pilgrimage story, agent-facing content and commercial
          starting reference in one place. Final NET pricing will be confirmed
          according to the requested dates, season, group size, room
          configuration, availability and current supplier rates.
        </p>
      </div>

      <TourForm
        action={createTour}
      />
    </div>
  );
}