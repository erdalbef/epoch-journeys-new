import Link from "next/link";
import { notFound } from "next/navigation";
import {
  AccountingCategory,
  AccountingPeriodStatus,
  CashTransactionDirection,
  CashTransactionStatus,
  ExpensePaymentSource,
  ExpenseReimbursementStatus,
} from "@prisma/client";
import AccountingDocumentActions from "@/components/admin/accounting/AccountingDocumentActions";
import AccountingPeriodActions from "@/components/admin/accounting/AccountingPeriodActions";
import AccountantPackageCard from "@/components/admin/accounting/AccountantPackageCard";
import {
  ArrowLeft,
  Banknote,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  CheckCircle2,
  CircleDollarSign,
  FileArchive,
  FileText,
  FileUp,
  FolderOpen,
  Landmark,
  ReceiptText,
  UserRound,
} from "lucide-react";

import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

type PageProps = {
  params: Promise<{
    year: string;
    month: string;
  }>;
  searchParams: Promise<{
    category?: string;
    uploaded?: string;
    updated?: string;
    statementUploaded?: string;
  }>;
};

const categoryDefinitions = [
  {
    category: AccountingCategory.BANK_STATEMENTS,
    number: "01",
    title: "Bank Statements",
    description:
      "EUR bank statements in PDF and Excel/CSV format where available.",
    icon: Landmark,
  },
  {
    category: AccountingCategory.SALES_INCOME,
    number: "02",
    title: "Sales / Income",
    description:
      "Sales invoices, customer advances, customer payments, credit notes, and other income documents.",
    icon: CircleDollarSign,
  },
  {
    category: AccountingCategory.EXPENSES_PURCHASES,
    number: "03",
    title: "Expenses / Purchases",
    description:
      "Hotels, accommodation, transport, transfers, restaurants, meals, guides, excursions, entrance fees, and other supplier documents.",
    icon: ReceiptText,
  },
  {
    category: AccountingCategory.CASH,
    number: "04",
    title: "Cash",
    description:
      "Cash receipts and cash payments with the related supporting documents.",
    icon: Banknote,
  },
  {
    category: AccountingCategory.EMPLOYEES_ACCOUNTABLE_PERSONS,
    number: "05",
    title: "Employees / Accountable Persons",
    description:
      "Travel expenses, expenses paid personally by employees, expense reports, and settlements.",
    icon: BriefcaseBusiness,
  },
  {
    category: AccountingCategory.OWNER_PERSONAL_PAYMENTS,
    number: "06",
    title: "Owner / Personal Payments",
    description:
      "Company expenses paid personally by the owner, funds provided by the owner, and reimbursements.",
    icon: UserRound,
  },
  {
    category: AccountingCategory.OTHER_DOCUMENTS,
    number: "07",
    title: "Other Documents",
    description:
      "Contracts, loans, financing, insurance, and other accounting-related documents.",
    icon: FileArchive,
  },
  {
    category: AccountingCategory.TRIP_GROUP_DOCUMENTATION,
    number: "08",
    title: "Trip / Group Documentation",
    description:
      "Tour and group references, itineraries, booking confirmations, vouchers, and supporting documents.",
    icon: Building2,
  },
] as const;

function isAccountingCategory(
  value: string | undefined,
): value is AccountingCategory {
  if (!value) return false;

  return Object.values(AccountingCategory).includes(
    value as AccountingCategory,
  );
}

function getMonthName(month: number) {
  return new Intl.DateTimeFormat("en-GB", {
    month: "long",
  }).format(new Date(Date.UTC(2026, month - 1, 1)));
}

function getDueDate(year: number, month: number) {
  const nextMonth = month === 12 ? 1 : month + 1;
  const nextYear = month === 12 ? year + 1 : year;

  return new Date(Date.UTC(nextYear, nextMonth - 1, 5, 12, 0, 0));
}

function formatDate(value: Date | null | undefined) {
  if (!value) return "—";

  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(value);
}

function formatMoney(value: number, currency: string) {
  try {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  } catch {
    return `${currency} ${value.toFixed(2)}`;
  }
}

function formatFileSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;

  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;

  return `${(kb / 1024).toFixed(1)} MB`;
}

function getStatusLabel(status: AccountingPeriodStatus) {
  switch (status) {
    case AccountingPeriodStatus.OPEN:
      return "Open";
    case AccountingPeriodStatus.REVIEW:
      return "Under Review";
    case AccountingPeriodStatus.READY:
      return "Ready for Accountant";
    case AccountingPeriodStatus.SUBMITTED:
      return "Submitted";
    case AccountingPeriodStatus.CLOSED:
      return "Closed";
  }
}

function getStatusClasses(status: AccountingPeriodStatus) {
  switch (status) {
    case AccountingPeriodStatus.OPEN:
      return "bg-blue-50 text-blue-700 ring-blue-200";
    case AccountingPeriodStatus.REVIEW:
      return "bg-amber-50 text-amber-700 ring-amber-200";
    case AccountingPeriodStatus.READY:
      return "bg-emerald-50 text-emerald-700 ring-emerald-200";
    case AccountingPeriodStatus.SUBMITTED:
      return "bg-indigo-50 text-indigo-700 ring-indigo-200";
    case AccountingPeriodStatus.CLOSED:
      return "bg-slate-100 text-slate-700 ring-slate-200";
  }
}

function getCategoryDefinition(category: AccountingCategory) {
  return categoryDefinitions.find((item) => item.category === category);
}

function getDocumentTypeLabel(value: string) {
  return value
    .replaceAll("_", " ")
    .toLowerCase()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export default async function AccountingMonthPage({
  params,
  searchParams,
}: PageProps) {
  const { year: yearParam, month: monthParam } = await params;
  const query = await searchParams;

  const year = Number(yearParam);
  const month = Number(monthParam);

  if (
    !Number.isInteger(year) ||
    !Number.isInteger(month) ||
    year < 2000 ||
    year > 2100 ||
    month < 1 ||
    month > 12
  ) {
    notFound();
  }

  const selectedCategory = isAccountingCategory(query.category)
    ? query.category
    : null;

  const period = await db.accountingPeriod.upsert({
    where: {
      year_month: {
        year,
        month,
      },
    },
    update: {},
    create: {
      year,
      month,
      dueDate: getDueDate(year, month),
    },
    include: {
      documents: {
        orderBy: [{ documentDate: "desc" }, { createdAt: "desc" }],
        include: {
          supplier: {
            select: {
              id: true,
              name: true,
            },
          },
          booking: {
            select: {
              id: true,
              bookingReference: true,
              groupName: true,
            },
          },
          tour: {
            select: {
              id: true,
              title: true,
            },
          },
          bankAccount: {
            select: {
              id: true,
              name: true,
              currency: true,
            },
          },
          uploadedBy: {
            select: {
              id: true,
              fullName: true,
              email: true,
            },
          },
        },
      },
      bankStatements: {
        where: {
          currency: "EUR",
        },
        orderBy: {
          statementDate: "desc",
        },
        include: {
          bankAccount: {
            select: {
              id: true,
              name: true,
              currency: true,
            },
          },
          uploadedBy: {
            select: {
              id: true,
              fullName: true,
              email: true,
            },
          },
        },
      },
      cashTransactions: {
        orderBy: [{ transactionDate: "desc" }, { createdAt: "desc" }],
        select: {
          id: true,
          direction: true,
          status: true,
          transactionDate: true,
          amount: true,
          currency: true,
          counterparty: true,
          description: true,
          reference: true,
        },
      },
    },
  });

  const periodStart = new Date(Date.UTC(year, month - 1, 1));
  const periodEnd = new Date(Date.UTC(year, month, 1));

  const personalExpenses = await db.expense.findMany({
    where: {
      expenseDate: {
        gte: periodStart,
        lt: periodEnd,
      },
      paymentSource: {
        in: [
          ExpensePaymentSource.EMPLOYEE_PERSONAL,
          ExpensePaymentSource.OWNER_PERSONAL,
        ],
      },
    },
    orderBy: [{ expenseDate: "desc" }, { createdAt: "desc" }],
    select: {
      id: true,
      title: true,
      vendorName: true,
      expenseDate: true,
      amount: true,
      currency: true,
      spenderName: true,
      paymentSource: true,
      reimbursementStatus: true,
      reimbursedAmount: true,
      reimbursementReference: true,
      booking: {
        select: {
          bookingReference: true,
          groupName: true,
        },
      },
      tour: {
        select: {
          title: true,
        },
      },
    },
  });

  const employeeExpenses = personalExpenses.filter(
    (expense) =>
      expense.paymentSource === ExpensePaymentSource.EMPLOYEE_PERSONAL,
  );

  const ownerExpenses = personalExpenses.filter(
    (expense) =>
      expense.paymentSource === ExpensePaymentSource.OWNER_PERSONAL,
  );

  const isClosed = period.status === AccountingPeriodStatus.CLOSED;

  const postedCashTransactions = period.cashTransactions.filter(
    (transaction) => transaction.status === CashTransactionStatus.POSTED,
  );

  const categoryCounts = new Map<AccountingCategory, number>();

  for (const definition of categoryDefinitions) {
    categoryCounts.set(
      definition.category,
      period.documents.filter(
        (document) => document.accountingCategory === definition.category,
      ).length,
    );
  }

  const financeBankDocumentCount =
    categoryCounts.get(AccountingCategory.BANK_STATEMENTS) ?? 0;

  categoryCounts.set(
    AccountingCategory.BANK_STATEMENTS,
    financeBankDocumentCount + period.bankStatements.length,
  );

  const cashDocumentCount = categoryCounts.get(AccountingCategory.CASH) ?? 0;
  categoryCounts.set(
    AccountingCategory.CASH,
    cashDocumentCount + postedCashTransactions.length,
  );

  const employeeDocumentCount =
    categoryCounts.get(AccountingCategory.EMPLOYEES_ACCOUNTABLE_PERSONS) ?? 0;
  categoryCounts.set(
    AccountingCategory.EMPLOYEES_ACCOUNTABLE_PERSONS,
    employeeDocumentCount + employeeExpenses.length,
  );

  const ownerDocumentCount =
    categoryCounts.get(AccountingCategory.OWNER_PERSONAL_PAYMENTS) ?? 0;
  categoryCounts.set(
    AccountingCategory.OWNER_PERSONAL_PAYMENTS,
    ownerDocumentCount + ownerExpenses.length,
  );

  const totalDocuments = period.documents.length + period.bankStatements.length;

  const uncategorizedCount = period.documents.filter(
    (document) => !document.accountingCategory,
  ).length;

  const populatedCategories = categoryDefinitions.filter(
    (definition) => (categoryCounts.get(definition.category) ?? 0) > 0,
  ).length;

  const filteredDocuments = selectedCategory
    ? period.documents.filter(
        (document) => document.accountingCategory === selectedCategory,
      )
    : period.documents;

  const showBankStatements =
    !selectedCategory || selectedCategory === AccountingCategory.BANK_STATEMENTS;

  const showCash =
    !selectedCategory || selectedCategory === AccountingCategory.CASH;

  const showEmployeeExpenses =
    !selectedCategory ||
    selectedCategory === AccountingCategory.EMPLOYEES_ACCOUNTABLE_PERSONS;

  const showOwnerExpenses =
    !selectedCategory ||
    selectedCategory === AccountingCategory.OWNER_PERSONAL_PAYMENTS;

  const selectedDefinition = selectedCategory
    ? getCategoryDefinition(selectedCategory)
    : null;

  const uploadHref =
    `/admin/accounting/upload?year=${year}&month=${month}` +
    (selectedCategory ? `&category=${selectedCategory}` : "");

  const hasEurBankStatement = period.bankStatements.length > 0;
  const hasUncategorizedDocuments = uncategorizedCount > 0;

  const part1Categories = new Set<AccountingCategory>([
    AccountingCategory.BANK_STATEMENTS,
    AccountingCategory.SALES_INCOME,
    AccountingCategory.EXPENSES_PURCHASES,
    AccountingCategory.CASH,
  ]);

  const part2Categories = new Set<AccountingCategory>([
    AccountingCategory.EMPLOYEES_ACCOUNTABLE_PERSONS,
    AccountingCategory.OWNER_PERSONAL_PAYMENTS,
    AccountingCategory.OTHER_DOCUMENTS,
    AccountingCategory.TRIP_GROUP_DOCUMENTATION,
  ]);

  const part1FinanceDocumentCount = period.documents.filter(
    (document) =>
      document.accountingCategory !== null &&
      part1Categories.has(document.accountingCategory),
  ).length;

  const part2FinanceDocumentCount = period.documents.filter(
    (document) =>
      document.accountingCategory !== null &&
      part2Categories.has(document.accountingCategory),
  ).length;

  const part2DocumentCount =
    part2FinanceDocumentCount + employeeExpenses.length + ownerExpenses.length;

  const part1DocumentCount =
    part1FinanceDocumentCount +
    period.bankStatements.length +
    postedCashTransactions.length;

  const hasPart1Package = part1DocumentCount > 0;

  const periodAlreadySubmitted =
    period.status === AccountingPeriodStatus.SUBMITTED ||
    period.status === AccountingPeriodStatus.CLOSED;

  const monthlyReady =
    hasEurBankStatement && !hasUncategorizedDocuments && hasPart1Package;

  const readinessIssueCount = [
    !hasEurBankStatement,
    hasUncategorizedDocuments,
    !hasPart1Package,
  ].filter(Boolean).length;

  const cashTotals = new Map<
    string,
    {
      receipts: number;
      payments: number;
    }
  >();

  for (const transaction of postedCashTransactions) {
    const currency = transaction.currency.trim().toUpperCase() || "EUR";
    const current = cashTotals.get(currency) ?? {
      receipts: 0,
      payments: 0,
    };

    const amount = Number(transaction.amount);

    if (transaction.direction === CashTransactionDirection.RECEIPT) {
      current.receipts += amount;
    } else {
      current.payments += amount;
    }

    cashTotals.set(currency, current);
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <Link
            href="/admin/accounting"
            className="mb-4 inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition hover:text-[#8B0000]"
          >
            <ArrowLeft className="h-4 w-4" />
            Accounting Dashboard
          </Link>

          <div className="flex items-center gap-2 text-sm font-semibold text-[#8B0000]">
            <CalendarDays className="h-4 w-4" />
            Monthly Accounting
          </div>

          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-[#0B1F3A]">
            {getMonthName(month)} {year}
          </h1>

          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
            Review the complete documentation for this accounting period and
            prepare the monthly accountant package.
          </p>
        </div>

        <div className="flex flex-col items-start gap-3 xl:items-end">
          <span
            className={`inline-flex rounded-full px-3 py-1.5 text-xs font-semibold ring-1 ring-inset ${getStatusClasses(
              period.status,
            )}`}
          >
            {getStatusLabel(period.status)}
          </span>

          <p className="text-xs text-slate-500">
            Accountant due date:{" "}
            <span className="font-semibold text-slate-700">
              {formatDate(period.dueDate)}
            </span>
          </p>

          {isClosed ? (
            <div className="inline-flex items-center justify-center rounded-lg border border-slate-200 bg-slate-100 px-4 py-2.5 text-sm font-semibold text-slate-600">
              Closed Period - Read Only
            </div>
          ) : (
            <Link
              href={uploadHref}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#8B0000] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#6f0000]"
            >
              <FileUp className="h-4 w-4" />
              Upload Document
            </Link>
          )}
        </div>
      </div>

      {isClosed ? (
        <section className="rounded-xl border border-slate-300 bg-slate-100 px-5 py-4">
          <div className="flex gap-3">
            <FileArchive className="mt-0.5 h-5 w-5 shrink-0 text-slate-700" />
            <div>
              <p className="text-sm font-semibold text-slate-900">
                This accounting period is closed and read-only.
              </p>
              <p className="mt-1 text-sm leading-6 text-slate-600">
                Documents, cash records and bank statements remain available
                for review, but changes are disabled until the period is
                reopened.
              </p>
            </div>
          </div>
        </section>
      ) : null}

      {query.uploaded === "1" ? (
        <SuccessNotice
          title="Document uploaded successfully"
          detail="The document has been added to this monthly accounting period."
        />
      ) : null}

      {query.updated === "1" ? (
        <SuccessNotice
          title="Document updated successfully"
          detail="The accounting document and its classification have been updated."
        />
      ) : null}

      {query.statementUploaded === "1" ? (
        <SuccessNotice
          title="Bank statement uploaded successfully"
          detail="The EUR bank statement has been added to this accounting period."
        />
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard icon={FileText} label="Documents" value={String(totalDocuments)} />
        <KpiCard
          icon={CheckCircle2}
          label="Categories Used"
          value={`${populatedCategories}/8`}
        />
        <KpiCard
          icon={Landmark}
          label="EUR Statements"
          value={String(period.bankStatements.length)}
        />
        <KpiCard
          icon={FolderOpen}
          label="Uncategorized"
          value={String(uncategorizedCount)}
          warning={uncategorizedCount > 0}
        />
      </section>

      <section
        className={`rounded-2xl border p-5 shadow-sm ${
          monthlyReady
            ? "border-emerald-200 bg-emerald-50"
            : "border-amber-200 bg-amber-50"
        }`}
      >
        <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
          <div>
            <div className="flex items-center gap-3">
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                  monthlyReady
                    ? "bg-emerald-100 text-emerald-700"
                    : "bg-amber-100 text-amber-700"
                }`}
              >
                {monthlyReady ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <FileArchive className="h-5 w-5" />
                )}
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#8B0000]">
                  Monthly Readiness
                </p>
                <h2
                  className={`mt-1 text-xl font-semibold ${
                    monthlyReady ? "text-emerald-900" : "text-amber-900"
                  }`}
                >
                  {periodAlreadySubmitted
                    ? getStatusLabel(period.status)
                    : monthlyReady
                      ? "Ready for Accountant Review"
                      : "Accounting Month Needs Attention"}
                </h2>
              </div>
            </div>

            <p
              className={`mt-3 max-w-3xl text-sm leading-6 ${
                monthlyReady ? "text-emerald-800" : "text-amber-800"
              }`}
            >
              {periodAlreadySubmitted
                ? period.status === AccountingPeriodStatus.CLOSED
                  ? "This accounting month has been closed. The records are preserved in read-only mode."
                  : "The accounting package has been submitted to the accountant."
                : monthlyReady
                  ? "The essential monthly accounting checks are complete. Review the package before changing the period to Ready for Accountant."
                  : `${readinessIssueCount} essential readiness ${
                      readinessIssueCount === 1
                        ? "item requires"
                        : "items require"
                    } attention before the month should be marked Ready for Accountant.`}
            </p>
          </div>

          <div className="space-y-3">
            <div className="rounded-xl bg-white/70 px-4 py-3 text-center">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                Current Period Status
              </p>
              <p className="mt-1 font-bold text-[#0B1F3A]">
                {getStatusLabel(period.status)}
              </p>
            </div>

            <AccountingPeriodActions
              year={year}
              month={month}
              status={period.status}
              monthlyReady={monthlyReady}
            />
          </div>
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          <ReadinessItem
            title="EUR Bank Statement"
            detail={
              hasEurBankStatement
                ? `${period.bankStatements.length} statement${
                    period.bankStatements.length === 1 ? "" : "s"
                  } available`
                : "Statement missing"
            }
            ok={hasEurBankStatement}
            required
          />
          <ReadinessItem
            title="Classification"
            detail={
              uncategorizedCount === 0
                ? "All documents classified"
                : `${uncategorizedCount} document${
                    uncategorizedCount === 1 ? "" : "s"
                  } need classification`
            }
            ok={uncategorizedCount === 0}
            required
          />
          <ReadinessItem
            title="Part 1 Package"
            detail={`${part1DocumentCount} item${
              part1DocumentCount === 1 ? "" : "s"
            } including posted cash entries`}
            ok={hasPart1Package}
            required
          />
          <ReadinessItem
            title="Part 2 Package"
            detail={
              part2DocumentCount > 0
                ? `${part2DocumentCount} document${
                    part2DocumentCount === 1 ? "" : "s"
                  }`
                : "No documents this month"
            }
            ok
            optional
          />
          <ReadinessItem
            title="Category Coverage"
            detail={`${populatedCategories} of 8 used`}
            ok
            optional
          />
        </div>

        <div className="mt-4 rounded-xl border border-current/10 bg-white/60 px-4 py-3 text-xs leading-5 text-slate-600">
          <strong>Important:</strong> all eight categories are not required
          every month. Empty categories such as Cash, Employee Expenses or
          Owner Payments are acceptable when there were no such transactions
          during the accounting period.
        </div>
      </section>

      <AccountantPackageCard
        year={year}
        month={month}
        part1Count={part1DocumentCount}
        part2Count={part2DocumentCount}
      />

      <section>
        <div className="mb-4">
          <h2 className="text-xl font-semibold text-[#0B1F3A]">
            Accountant Categories
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Select a category to review only the documents and accounting
            records belonging to that section.
          </p>
        </div>

        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {categoryDefinitions.map((definition) => {
            const Icon = definition.icon;
            const count = categoryCounts.get(definition.category) ?? 0;
            const active = selectedCategory === definition.category;
            const countLabel =
              definition.category === AccountingCategory.CASH ||
              definition.category === AccountingCategory.EMPLOYEES_ACCOUNTABLE_PERSONS ||
              definition.category === AccountingCategory.OWNER_PERSONAL_PAYMENTS
                ? count === 1
                  ? "record"
                  : "records"
                : count === 1
                  ? "document"
                  : "documents";

            return (
              <Link
                key={definition.category}
                href={`/admin/accounting/${year}/${month}?category=${definition.category}`}
                className={`rounded-2xl border p-4 transition ${
                  active
                    ? "border-[#8B0000] bg-red-50 shadow-sm"
                    : "bg-white hover:border-slate-300 hover:shadow-sm"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
                      active
                        ? "bg-[#8B0000] text-white"
                        : "bg-[#0B1F3A] text-white"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>

                  <div className="min-w-0">
                    <p className="text-xs font-bold uppercase tracking-[0.14em] text-[#8B0000]">
                      {definition.number}
                    </p>
                    <p className="mt-1 text-sm font-semibold text-slate-900">
                      {definition.title}
                    </p>
                    <p className="mt-2 text-xs text-slate-500">
                      {count} {countLabel}
                    </p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        {selectedCategory ? (
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <Link
              href={`/admin/accounting/${year}/${month}`}
              className="text-sm font-semibold text-[#8B0000] underline underline-offset-4"
            >
              Show all categories
            </Link>

            {!isClosed ? (
              <Link
                href={uploadHref}
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#8B0000]"
              >
                <FileUp className="h-4 w-4" />
                Upload to this category
              </Link>
            ) : null}

            {selectedCategory === AccountingCategory.CASH ? (
              <Link
                href={`/admin/accounting/cash?year=${year}&month=${month}`}
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B1F3A]"
              >
                <Banknote className="h-4 w-4" />
                Open Cash Register
              </Link>
            ) : null}

            {selectedCategory ===
              AccountingCategory.EMPLOYEES_ACCOUNTABLE_PERSONS ||
            selectedCategory === AccountingCategory.OWNER_PERSONAL_PAYMENTS ? (
              <Link
                href="/admin/finance/expenses/create"
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B1F3A]"
              >
                <ReceiptText className="h-4 w-4" />
                Add Personal-Paid Expense
              </Link>
            ) : null}
          </div>
        ) : null}
      </section>

      {showCash ? (
        <section className="rounded-2xl border bg-white shadow-sm">
          <div className="border-b px-6 py-5">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-3">
                <div className="rounded-xl bg-[#0B1F3A] p-2.5 text-white">
                  <Banknote className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#0B1F3A]">
                    Cash Register
                  </h2>
                  <p className="mt-1 text-sm text-slate-600">
                    Posted cash receipts and payments recorded for this
                    accounting month.
                  </p>
                </div>
              </div>

              <Link
                href={`/admin/accounting/cash?year=${year}&month=${month}`}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#8B0000] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#6f0000]"
              >
                <Banknote className="h-4 w-4" />
                Open Cash Register
              </Link>
            </div>
          </div>

          {postedCashTransactions.length === 0 ? (
            <div className="px-6 py-10 text-center">
              <Banknote className="mx-auto h-9 w-9 text-slate-300" />
              <p className="mt-3 font-medium text-slate-700">
                No posted cash activity for this month.
              </p>
              <p className="mt-1 text-sm text-slate-500">
                This is acceptable when there were no cash transactions.
              </p>
            </div>
          ) : (
            <div className="p-6">
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {Array.from(cashTotals.entries())
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([currency, values]) => (
                    <div key={currency} className="rounded-xl border p-4">
                      <p className="font-bold text-[#0B1F3A]">{currency}</p>
                      <div className="mt-3 grid gap-2 sm:grid-cols-3">
                        <div>
                          <p className="text-xs text-slate-500">Received</p>
                          <p className="mt-1 text-sm font-semibold text-emerald-700">
                            {formatMoney(values.receipts, currency)}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500">Paid</p>
                          <p className="mt-1 text-sm font-semibold text-red-700">
                            {formatMoney(values.payments, currency)}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500">Net</p>
                          <p className="mt-1 text-sm font-semibold text-[#0B1F3A]">
                            {formatMoney(
                              values.receipts - values.payments,
                              currency,
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </section>
      ) : null}

      {showEmployeeExpenses ? (
        <PersonalExpenseRegister
          title="Employees / Accountable Persons"
          description="Company expenses paid personally by employees or accountable persons, including reimbursement tracking."
          expenses={employeeExpenses}
          icon={BriefcaseBusiness}
        />
      ) : null}

      {showOwnerExpenses ? (
        <PersonalExpenseRegister
          title="Owner / Personal Payments"
          description="Company expenses paid personally by the owner, with reimbursement and settlement tracking."
          expenses={ownerExpenses}
          icon={UserRound}
        />
      ) : null}

      <section className="rounded-2xl border bg-white shadow-sm">
        <div className="border-b px-6 py-5">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#8B0000]">
                {selectedDefinition
                  ? selectedDefinition.number
                  : "Monthly File Register"}
              </p>
              <h2 className="mt-1 text-lg font-semibold text-[#0B1F3A]">
                {selectedDefinition
                  ? selectedDefinition.title
                  : "Accounting Documents"}
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                {selectedDefinition
                  ? selectedDefinition.description
                  : "All Finance Documents assigned to this accounting month."}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="rounded-lg bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700">
                {filteredDocuments.length} finance{" "}
                {filteredDocuments.length === 1 ? "document" : "documents"}
              </div>

              {!isClosed ? (
                <Link
                  href={uploadHref}
                  className="inline-flex items-center gap-2 rounded-lg border border-[#8B0000] px-3 py-2 text-xs font-semibold text-[#8B0000] transition hover:bg-red-50"
                >
                  <FileUp className="h-4 w-4" />
                  Upload
                </Link>
              ) : (
                <span className="rounded-lg border border-slate-200 bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-500">
                  Read Only
                </span>
              )}
            </div>
          </div>
        </div>

        {filteredDocuments.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <FileArchive className="mx-auto h-9 w-9 text-slate-300" />
            <p className="mt-3 font-medium text-slate-700">
              No finance documents in this section yet.
            </p>
            <p className="mt-1 text-sm text-slate-500">
              {isClosed
                ? "This accounting period is closed and cannot accept new documents."
                : "Upload the first accounting document for this section."}
            </p>
            {!isClosed ? (
              <Link
                href={uploadHref}
                className="mt-5 inline-flex items-center gap-2 rounded-lg bg-[#8B0000] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#6f0000]"
              >
                <FileUp className="h-4 w-4" />
                Upload Document
              </Link>
            ) : null}
          </div>
        ) : (
          <div className="divide-y">
            {filteredDocuments.map((document) => {
              const relatedName =
                document.supplier?.name ??
                document.booking?.groupName ??
                document.booking?.bookingReference ??
                document.tour?.title ??
                document.bankAccount?.name ??
                null;

              const uploadedBy =
                document.uploadedBy?.fullName ??
                document.uploadedBy?.email ??
                null;

              return (
                <div key={document.id} className="px-6 py-5">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div className="flex min-w-0 gap-4">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-100">
                        <FileText className="h-5 w-5 text-[#0B1F3A]" />
                      </div>

                      <div className="min-w-0">
                        <p className="font-semibold text-slate-900">
                          {document.title}
                        </p>
                        <p className="mt-1 break-all text-sm text-slate-500">
                          {document.originalFileName}
                        </p>

                        <div className="mt-3 flex flex-wrap gap-2">
                          <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700">
                            {getDocumentTypeLabel(document.type)}
                          </span>
                          {document.accountingSubcategory ? (
                            <span className="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-700">
                              {document.accountingSubcategory}
                            </span>
                          ) : null}
                          {relatedName ? (
                            <span className="rounded-full bg-amber-50 px-2.5 py-1 text-xs font-medium text-amber-700">
                              {relatedName}
                            </span>
                          ) : null}
                        </div>

                        <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-slate-500">
                          <span>
                            Date: {formatDate(document.documentDate ?? document.createdAt)}
                          </span>
                          <span>Size: {formatFileSize(document.fileSize)}</span>
                          {document.referenceNumber ? (
                            <span>Ref: {document.referenceNumber}</span>
                          ) : null}
                          {uploadedBy ? <span>Uploaded by: {uploadedBy}</span> : null}
                        </div>
                      </div>
                    </div>

                    <div className="flex shrink-0 flex-wrap items-center gap-2">
                      <a
                        href={document.storagePath}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center justify-center rounded-lg border px-3 py-2 text-sm font-semibold text-[#0B1F3A] transition hover:bg-slate-50"
                      >
                        Open Document
                      </a>

                      <AccountingDocumentActions
                        documentId={document.id}
                        year={year}
                        month={month}
                        category={document.accountingCategory}
                        readOnly={isClosed}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {showBankStatements ? (
        <section className="rounded-2xl border bg-white shadow-sm">
          <div className="border-b px-6 py-5">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <div className="rounded-xl bg-[#0B1F3A] p-2.5 text-white">
                  <Landmark className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#0B1F3A]">
                    EUR Bank Statements
                  </h2>
                  <p className="mt-1 text-sm text-slate-600">
                    Separate bank statement records assigned to this accounting
                    month.
                  </p>
                </div>
              </div>

              {isClosed ? (
                <span className="inline-flex shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-slate-100 px-4 py-2.5 text-sm font-semibold text-slate-500">
                  Closed Period
                </span>
              ) : (
                <Link
                  href={`/admin/accounting/bank-statements/upload?year=${year}&month=${month}`}
                  className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-[#8B0000] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#6f0000]"
                >
                  <FileUp className="h-4 w-4" />
                  Upload Bank Statement
                </Link>
              )}
            </div>
          </div>

          {period.bankStatements.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <Landmark className="mx-auto h-9 w-9 text-slate-300" />
              <p className="mt-3 font-medium text-slate-700">
                No EUR bank statements uploaded for this month.
              </p>
              <p className="mt-1 text-sm text-slate-500">
                {isClosed
                  ? "This accounting period is closed and cannot accept additional bank statements."
                  : "Complete bank statements use the dedicated Bank Statement upload flow."}
              </p>
            </div>
          ) : (
            <div className="divide-y">
              {period.bankStatements.map((statement) => {
                const uploadedBy =
                  statement.uploadedBy?.fullName ??
                  statement.uploadedBy?.email ??
                  null;

                return (
                  <div
                    key={statement.id}
                    className="flex flex-col gap-4 px-6 py-5 md:flex-row md:items-center md:justify-between"
                  >
                    <div>
                      <p className="font-semibold text-slate-900">
                        {statement.bankAccount.name}
                      </p>
                      <p className="mt-1 text-sm text-slate-500">
                        Statement date: {formatDate(statement.statementDate)}
                      </p>
                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                        <span>Currency: {statement.currency}</span>
                        <span>Status: {getDocumentTypeLabel(statement.status)}</span>
                        {statement.fileName ? <span>File: {statement.fileName}</span> : null}
                        {uploadedBy ? <span>Uploaded by: {uploadedBy}</span> : null}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="w-fit rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                        EUR
                      </span>
                      {isClosed ? (
                        <span className="w-fit rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
                          Read Only
                        </span>
                      ) : null}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      ) : null}

      {uncategorizedCount > 0 && !selectedCategory ? (
        <section className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
          <div className="flex gap-3">
            <FileArchive className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" />
            <div>
              <h3 className="font-semibold text-amber-900">
                Documents requiring classification
              </h3>
              <p className="mt-1 text-sm leading-6 text-amber-800">
                {uncategorizedCount} {uncategorizedCount === 1 ? "document has" : "documents have"} been assigned to this month but not yet assigned to one of the accountant&apos;s eight categories.
              </p>
              {isClosed ? (
                <p className="mt-2 text-sm font-semibold text-amber-900">
                  Reopen this period before correcting the classification.
                </p>
              ) : null}
            </div>
          </div>
        </section>
      ) : null}
    </div>
  );
}


function PersonalExpenseRegister({
  title,
  description,
  expenses,
  icon: Icon,
}: {
  title: string;
  description: string;
  expenses: Array<{
    id: string;
    title: string;
    vendorName: string | null;
    expenseDate: Date;
    amount: number;
    currency: string;
    spenderName: string | null;
    reimbursementStatus: ExpenseReimbursementStatus;
    reimbursedAmount: number;
    reimbursementReference: string | null;
    booking: {
      bookingReference: string;
      groupName: string | null;
    } | null;
    tour: {
      title: string;
    } | null;
  }>;
  icon: typeof FileText;
}) {
  const total = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const reimbursed = expenses.reduce(
    (sum, expense) => sum + expense.reimbursedAmount,
    0,
  );
  const outstanding = Math.max(0, total - reimbursed);

  return (
    <section className="rounded-2xl border bg-white shadow-sm">
      <div className="border-b px-6 py-5">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-[#0B1F3A] p-2.5 text-white">
              <Icon className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-[#0B1F3A]">{title}</h2>
              <p className="mt-1 text-sm text-slate-600">{description}</p>
            </div>
          </div>

          <Link
            href="/admin/finance/expenses/create"
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#8B0000] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#6f0000]"
          >
            <ReceiptText className="h-4 w-4" />
            Add Expense
          </Link>
        </div>
      </div>

      {expenses.length === 0 ? (
        <div className="px-6 py-10 text-center">
          <Icon className="mx-auto h-9 w-9 text-slate-300" />
          <p className="mt-3 font-medium text-slate-700">
            No applicable personal-paid expenses for this month.
          </p>
          <p className="mt-1 text-sm text-slate-500">
            This is acceptable when no employee, accountable person or owner paid
            company expenses personally.
          </p>
        </div>
      ) : (
        <>
          <div className="grid gap-3 border-b p-6 sm:grid-cols-3">
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                Expense Total
              </p>
              <p className="mt-1 text-lg font-bold text-[#0B1F3A]">
                {formatMoney(total, "EUR")}
              </p>
            </div>
            <div className="rounded-xl bg-emerald-50 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-emerald-700">
                Reimbursed
              </p>
              <p className="mt-1 text-lg font-bold text-emerald-800">
                {formatMoney(reimbursed, "EUR")}
              </p>
            </div>
            <div className="rounded-xl bg-amber-50 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-amber-700">
                Outstanding
              </p>
              <p className="mt-1 text-lg font-bold text-amber-800">
                {formatMoney(outstanding, "EUR")}
              </p>
            </div>
          </div>

          <div className="divide-y">
            {expenses.map((expense) => {
              const outstandingAmount = Math.max(
                0,
                expense.amount - expense.reimbursedAmount,
              );

              return (
                <div key={expense.id} className="px-6 py-5">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                      <p className="font-semibold text-slate-900">
                        {expense.title}
                      </p>
                      <p className="mt-1 text-sm text-slate-500">
                        {expense.spenderName || "Person not specified"}
                        {expense.vendorName ? ` • ${expense.vendorName}` : ""}
                      </p>
                      <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-slate-500">
                        <span>Date: {formatDate(expense.expenseDate)}</span>
                        {expense.booking ? (
                          <span>
                            Booking:{" "}
                            {expense.booking.groupName ||
                              expense.booking.bookingReference}
                          </span>
                        ) : null}
                        {expense.tour ? <span>Tour: {expense.tour.title}</span> : null}
                        {expense.reimbursementReference ? (
                          <span>Ref: {expense.reimbursementReference}</span>
                        ) : null}
                      </div>
                    </div>

                    <div className="grid min-w-[300px] grid-cols-3 gap-3 text-right">
                      <div>
                        <p className="text-xs text-slate-500">Expense</p>
                        <p className="mt-1 text-sm font-semibold text-slate-900">
                          {formatMoney(expense.amount, expense.currency)}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Reimbursed</p>
                        <p className="mt-1 text-sm font-semibold text-emerald-700">
                          {formatMoney(
                            expense.reimbursedAmount,
                            expense.currency,
                          )}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Outstanding</p>
                        <p className="mt-1 text-sm font-semibold text-amber-700">
                          {formatMoney(outstandingAmount, expense.currency)}
                        </p>
                      </div>
                      <div className="col-span-3">
                        <span className="inline-flex rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700">
                          {getDocumentTypeLabel(expense.reimbursementStatus)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </section>
  );
}

function SuccessNotice({
  title,
  detail,
}: {
  title: string;
  detail: string;
}) {
  return (
    <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-5 py-4">
      <div className="flex items-center gap-3">
        <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-700" />
        <div>
          <p className="text-sm font-semibold text-emerald-900">{title}</p>
          <p className="mt-1 text-sm text-emerald-800">{detail}</p>
        </div>
      </div>
    </div>
  );
}

function KpiCard({
  icon: Icon,
  label,
  value,
  warning = false,
}: {
  icon: typeof FileText;
  label: string;
  value: string;
  warning?: boolean;
}) {
  return (
    <div className="rounded-2xl border bg-white p-5 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="rounded-xl bg-slate-100 p-2.5">
          <Icon className="h-5 w-5 text-[#0B1F3A]" />
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
            {label}
          </p>
          <p
            className={`mt-1 text-2xl font-semibold ${
              warning ? "text-amber-700" : "text-slate-900"
            }`}
          >
            {value}
          </p>
        </div>
      </div>
    </div>
  );
}

function ReadinessItem({
  title,
  detail,
  ok,
  required = false,
  optional = false,
}: {
  title: string;
  detail: string;
  ok: boolean;
  required?: boolean;
  optional?: boolean;
}) {
  return (
    <div className="rounded-xl border border-slate-200/80 bg-white p-4">
      <div className="flex items-start gap-3">
        <CheckCircle2
          className={`mt-0.5 h-5 w-5 shrink-0 ${
            ok ? "text-emerald-600" : "text-amber-600"
          }`}
        />
        <div>
          <p className="text-sm font-semibold text-slate-900">{title}</p>
          <p
            className={`mt-1 text-xs ${
              ok ? "text-slate-500" : "font-medium text-amber-700"
            }`}
          >
            {detail}
          </p>
          {required ? (
            <span className="mt-2 inline-flex rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-slate-500">
              Required
            </span>
          ) : null}
          {optional ? (
            <span className="mt-2 inline-flex rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-blue-600">
              If applicable
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}

